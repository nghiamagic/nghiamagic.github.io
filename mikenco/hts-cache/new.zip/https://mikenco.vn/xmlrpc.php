<!doctype html>
<html lang="vi">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="facebook-domain-verification" content="ho1youfo8pwpyzo7zhzawzb1cairq2" />
	<link rel="profile" href="https://gmpg.org/xfn/11">
	
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<title>Không tìm thấy trang này &#8211; Mikenco® Official Site</title>
<meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Dòng thông tin Mikenco® Official Site &raquo;" href="https://mikenco.vn/feed/" />
<link rel="alternate" type="application/rss+xml" title="Dòng phản hồi Mikenco® Official Site &raquo;" href="https://mikenco.vn/comments/feed/" />
		<script>
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/mikenco.vn\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.7.1"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='font-awesome-css'  href='https://mikenco.vn/wp-content/plugins/load-more-products-for-woocommerce/berocket/assets/css/font-awesome.min.css?ver=5.7.1' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='https://mikenco.vn/wp-includes/css/dist/block-library/style.min.css?ver=5.7.1' media='all' />
<link rel='stylesheet' id='wc-block-vendors-style-css'  href='https://mikenco.vn/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors-style.css?ver=4.7.2' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='https://mikenco.vn/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css?ver=4.7.2' media='all' />
<link rel='stylesheet' id='uaf_client_css-css'  href='https://mikenco.vn/wp-content/uploads/useanyfont/uaf.css?ver=1617685595' media='all' />
<link rel='stylesheet' id='woocommerce-layout-css'  href='https://mikenco.vn/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=5.2.2' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='https://mikenco.vn/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=5.2.2' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='https://mikenco.vn/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=5.2.2' media='all' />
<style id='woocommerce-inline-inline-css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='dgwt-wcas-style-css'  href='https://mikenco.vn/wp-content/plugins/ajax-search-for-woocommerce/assets/css/style.min.css?ver=1.9.0' media='all' />
<link rel='stylesheet' id='mikenco-style-css'  href='https://mikenco.vn/wp-content/themes/mikenco/style.css?ver=1.0.0' media='all' />
<link rel='stylesheet' id='wc-custom-add-to-cart-css'  href='https://mikenco.vn/wp-content/plugins/woo-custom-add-to-cart-button/assets/css/wc-custom-add-to-cart.min.css?ver=1.1.1' media='all' />
<script src='https://mikenco.vn/wp-includes/js/jquery/jquery.min.js?ver=3.5.1' id='jquery-core-js'></script>
<script src='https://mikenco.vn/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<link rel="https://api.w.org/" href="https://mikenco.vn/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://mikenco.vn/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://mikenco.vn/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.7.1" />
<meta name="generator" content="WooCommerce 5.2.2" />
<style></style><style>
                .lmp_load_more_button.br_lmp_button_settings .lmp_button:hover {
                    background-color: #ffffff!important;
                    color: #111111!important;
                }
                .lmp_load_more_button.br_lmp_prev_settings .lmp_button:hover {
                    background-color: #9999ff!important;
                    color: #111111!important;
                }li.product.lazy, .berocket_lgv_additional_data.lazy{opacity:0;}</style><style type="text/css">.dgwt-wcas-ico-magnifier,.dgwt-wcas-ico-magnifier-handler{max-width:20px}.dgwt-wcas-search-wrapp{max-width:400px}.dgwt-wcas-search-wrapp .dgwt-wcas-sf-wrapp input[type=search].dgwt-wcas-search-input,.dgwt-wcas-search-wrapp .dgwt-wcas-sf-wrapp input[type=search].dgwt-wcas-search-input:hover,.dgwt-wcas-search-wrapp .dgwt-wcas-sf-wrapp input[type=search].dgwt-wcas-search-input:focus{background-color:#fff;border-color:#fff}.dgwt-wcas-search-icon{color:#fff}.dgwt-wcas-search-icon path{fill:#fff}</style>	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	
<!-- Facebook Pixel Code -->
<script type='text/javascript'>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
</script>
<!-- End Facebook Pixel Code -->
<script type='text/javascript'>
  fbq('init', '1157378277937540', {}, {
    "agent": "wordpress-5.7.1-3.0.5"
});
</script><script type='text/javascript'>
  fbq('track', 'PageView', []);
</script>
<!-- Facebook Pixel Code -->
<noscript>
<img height="1" width="1" style="display:none" alt="fbpx"
src="https://www.facebook.com/tr?id=1157378277937540&ev=PageView&noscript=1" />
</noscript>
<!-- End Facebook Pixel Code -->
<style>.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>			<script  type="text/javascript">
				!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
					n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
					n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
					t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
					document,'script','https://connect.facebook.net/en_US/fbevents.js');
			</script>
			<!-- WooCommerce Facebook Integration Begin -->
			<script  type="text/javascript">

				fbq('init', '1157378277937540', {}, {
    "agent": "woocommerce-5.2.2-2.3.5"
});

				fbq( 'track', 'PageView', {
    "source": "woocommerce",
    "version": "5.2.2",
    "pluginVersion": "2.3.5"
} );

				document.addEventListener( 'DOMContentLoaded', function() {
					jQuery && jQuery( function( $ ) {
						// insert placeholder for events injected when a product is added to the cart through AJAX
						$( document.body ).append( '<div class=\"wc-facebook-pixel-event-placeholder\"></div>' );
					} );
				}, false );

			</script>
			<!-- WooCommerce Facebook Integration End -->
					<style type="text/css">
					.site-title,
			.site-description {
				position: absolute;
				clip: rect(1px, 1px, 1px, 1px);
				}
					</style>
		<link rel="icon" href="https://mikenco.vn/wp-content/uploads/2020/04/cropped-1-2-32x32.jpg" sizes="32x32" />
<link rel="icon" href="https://mikenco.vn/wp-content/uploads/2020/04/cropped-1-2-192x192.jpg" sizes="192x192" />
<link rel="apple-touch-icon" href="https://mikenco.vn/wp-content/uploads/2020/04/cropped-1-2-180x180.jpg" />
<meta name="msapplication-TileImage" content="https://mikenco.vn/wp-content/uploads/2020/04/cropped-1-2-270x270.jpg" />
		<script>
    $(document).ready(function(){
      $("#shop-dropdown").click(function(){
          
        $("#shop-dropdown").toggleClass("click-shop");
        $("#menu-cate").toggle();
      });
    });
    </script>
	<script>
	  (function() {
		var ta = document.createElement('script'); ta.type = 'text/javascript'; ta.async = true;
		ta.src = 'https://meteor.tiktok.com/i18n/pixel/sdk.js?sdkid=BR1PL08QGATOS731K0S0';
		var s = document.getElementsByTagName('script')[0];
		s.parentNode.insertBefore(ta, s);
	  })();
	</script>

</head>

<body class="error404 theme-mikenco woocommerce-no-js hfeed">

<div id="page" class="site">
	<div id="menu">
			<a href="http://mikenco.vn" id="logo">
				<img class="non-mobi only-homepage" src="http://mikenco.vn/wp-content/uploads/2020/10/logo-white.png" alt="">
				<img class="non-mobi none-homepage" src="http://mikenco.vn/wp-content/uploads/2020/10/logo.png" alt="">
				
			</a>
			<button onclick="myFunction()" id="hamburger" class="dropbtn">
				<img src="http://mikenco.vn/wp-content/uploads/2020/04/hamburger.png" alt="">
			</button>
			<div id="nav-menu"  class="dropdown-content">
				<nav>
					<ul>
						<li class="home-menu">
							<a href="http://mikenco.vn">HOME</a>
						</li>
						<li>
							<a id="shop-dropdown" href="#">PRODUCTS
                            </a>

							<ul id="menu-cate">
								<li>
								    <a href="http://mikenco.vn/all-collection">All Collection</a>
									
								</li>
								<li>
									<a href="http://mikenco.vn/premium-class/">Premium Class</a>
								</li>
								<li>
									<a href="http://mikenco.vn/special-prices">Special Prices</a>
								</li>
								<li>
									<a href="https://mikenco.vn/jacket/">Jackets</a>
								</li>
								<li>
									<a href="https://mikenco.vn/sweatshirts/">Sweaters</a>
								</li>
								<li>
									<a href="http://mikenco.vn/product-category/shirts/">Shirts</a>
								</li>
								<li>
									<a href="http://mikenco.vn/product-category/t-shirts/">T-Shirts</a>
								</li>
								<li>
									<a href="http://mikenco.vn/pants/">Pants</a>
								</li>
								<li>
									<a href="http://mikenco.vn/product-category/shorts/">Shorts</a>
								</li>
								<li>
									<a href="http://mikenco.vn/product-category/shoes/">Shoes</a>
								</li>
								
								<li>
									<a href="http://mikenco.vn/accessories/">Accessories</a>
								</li>
								<li>
									<a href="http://mikenco.vn/product-category/sandals/">SANDALS</a>
								</li>
							</ul>
							
						</li>
						<li>
							<a href="http://mikenco.vn/guarantee/">Warranty</a>
						</li>
						<li>
							<a href="http://mikenco.vn/member/">Member</a>
						</li>
						<li>
							<a href="http://mikenco.vn/stores/">STORES</a>
						</li>
						<li>
							<a href="#">
							<div class="dgwt-wcas-search-wrapp dgwt-wcas-no-submit woocommerce js-dgwt-wcas-layout-icon dgwt-wcas-layout-icon js-dgwt-wcas-mobile-overlay-enabled">
		<div class="dgwt-wcas-search-icon js-dgwt-wcas-search-icon-handler">				<svg version="1.1" class="dgwt-wcas-ico-magnifier-handler" xmlns="http://www.w3.org/2000/svg"
					 xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					 viewBox="0 0 51.539 51.361" enable-background="new 0 0 51.539 51.361" xml:space="preserve">
		             <path fill="#444" d="M51.539,49.356L37.247,35.065c3.273-3.74,5.272-8.623,5.272-13.983c0-11.742-9.518-21.26-21.26-21.26 S0,9.339,0,21.082s9.518,21.26,21.26,21.26c5.361,0,10.244-1.999,13.983-5.272l14.292,14.292L51.539,49.356z M2.835,21.082 c0-10.176,8.249-18.425,18.425-18.425s18.425,8.249,18.425,18.425S31.436,39.507,21.26,39.507S2.835,31.258,2.835,21.082z"/>
				</svg>
				</div>
	<div class="dgwt-wcas-search-icon-arrow"></div>
		<form class="dgwt-wcas-search-form" role="search" action="https://mikenco.vn/" method="get">
		<div class="dgwt-wcas-sf-wrapp">
							<svg version="1.1" class="dgwt-wcas-ico-magnifier" xmlns="http://www.w3.org/2000/svg"
					 xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					 viewBox="0 0 51.539 51.361" enable-background="new 0 0 51.539 51.361" xml:space="preserve">
		             <path fill="#444" d="M51.539,49.356L37.247,35.065c3.273-3.74,5.272-8.623,5.272-13.983c0-11.742-9.518-21.26-21.26-21.26 S0,9.339,0,21.082s9.518,21.26,21.26,21.26c5.361,0,10.244-1.999,13.983-5.272l14.292,14.292L51.539,49.356z M2.835,21.082 c0-10.176,8.249-18.425,18.425-18.425s18.425,8.249,18.425,18.425S31.436,39.507,21.26,39.507S2.835,31.258,2.835,21.082z"/>
				</svg>
							<label class="screen-reader-text"
			       for="dgwt-wcas-search-input-1923">Tìm kiếm sản phẩm</label>

			<input id="dgwt-wcas-search-input-1923"
			       type="search"
			       class="dgwt-wcas-search-input"
			       name="s"
			       value=""
			       placeholder="Tìm kiếm sản phẩm..."
			       autocomplete="off"
				   			/>
			<div class="dgwt-wcas-preloader"></div>

			
			<input type="hidden" name="post_type" value="product"/>
			<input type="hidden" name="dgwt_wcas" value="1"/>

			
					</div>
	</form>
</div>
							</a>
						</li>
					</ul>
				</nav>
			</div>
			
			<script>
			/* When the user clicks on the button, 
			toggle between hiding and showing the dropdown content */
			function myFunction() {
			  document.getElementById("nav-menu").classList.toggle("show");

			}
			</script>
			<a href="http://mikenco.vn/cart" id="cart">
				<img class="only-mobi" src="http://mikenco.vn/wp-content/uploads/2020/04/cart.png" alt="">
				<img  class="non-mobi" src="http://mikenco.vn/wp-content/uploads/2020/04/luxury-goods-tide-icon-comments-bag-cart-icon-11553457648rokwlpgpvq.png" alt="">
							</a>
		</div>
	<a class="skip-link screen-reader-text" href="#content">Skip to content</a>


	<div id="content" class="site-content">

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

			<section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title">Oops! That page can&rsquo;t be found.</h1>
				</header><!-- .page-header -->

				<div class="page-content">
					<p>It looks like nothing was found at this location. Maybe try one of the links below or a search?</p>

					<form role="search" method="get" class="search-form" action="https://mikenco.vn/">
				<label>
					<span class="screen-reader-text">Tìm kiếm cho:</span>
					<input type="search" class="search-field" placeholder="Tìm kiếm &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Tìm kiếm" />
			</form>
		<div class="widget widget_recent_entries">
		<h2 class="widgettitle">Bài viết mới</h2>
		<ul>
											<li>
					<a href="https://mikenco.vn/2020/03/25/feedback-27/">Feedback</a>
									</li>
											<li>
					<a href="https://mikenco.vn/2020/03/25/feedback-26/">Feedback</a>
									</li>
											<li>
					<a href="https://mikenco.vn/2020/03/25/feedback-25/">Feedback</a>
									</li>
											<li>
					<a href="https://mikenco.vn/2020/03/25/feedback-24/">Feedback</a>
									</li>
											<li>
					<a href="https://mikenco.vn/2020/03/02/feedback-23/">Feedback</a>
									</li>
					</ul>

		</div>
					<div class="widget widget_categories">
						<h2 class="widget-title">Most Used Categories</h2>
						<ul>
								<li class="cat-item cat-item-1"><a href="https://mikenco.vn/category/uncategorized/">Uncategorized</a> (58)
</li>
						</ul>
					</div><!-- .widget -->

					<div class="widget widget_archive"><h2 class="widgettitle">Lưu trữ</h2><p>Try looking in the monthly archives. 🙂</p>		<label class="screen-reader-text" for="archives-dropdown--1">Lưu trữ</label>
		<select id="archives-dropdown--1" name="archive-dropdown">
			
			<option value="">Chọn tháng</option>
				<option value='https://mikenco.vn/2020/03/'> Tháng Ba 2020 </option>
	<option value='https://mikenco.vn/2019/12/'> Tháng Mười Hai 2019 </option>
	<option value='https://mikenco.vn/2019/11/'> Tháng Mười Một 2019 </option>
	<option value='https://mikenco.vn/2019/09/'> Tháng Chín 2019 </option>
	<option value='https://mikenco.vn/2019/08/'> Tháng Tám 2019 </option>

		</select>

<script>
/* <![CDATA[ */
(function() {
	var dropdown = document.getElementById( "archives-dropdown--1" );
	function onSelectChange() {
		if ( dropdown.options[ dropdown.selectedIndex ].value !== '' ) {
			document.location.href = this.options[ this.selectedIndex ].value;
		}
	}
	dropdown.onchange = onSelectChange;
})();
/* ]]> */
</script>
			</div>
				</div><!-- .page-content -->
			</section><!-- .error-404 -->

		</main><!-- #main -->
	</div><!-- #primary -->


	</div><!-- #content -->

	<div class="clearfix"></div>
	<footer id="footer">
		<div class="col-12">
			<div class="row">
				<div class="footer-letf col-6">
					<div class="payment_methods">                                  
						<p style="margin-bottom: 10px;"><a href="http://mikenco.vn/general-policy/">GENERAL POLICY</a></p>
						<p style="margin-bottom: 10px;"><a href="http://mikenco.vn/privacy-policy/">PRIVACY POLICY</a></p>                                   
	                    <a href="http://online.gov.vn/CustomWebsiteDisplay.aspx?DocId=53069"><img src="http://mikenco.vn/wp-content/uploads/2020/04/trans_bo-cong-thuong.png" alt="Payment methods"></a>                                
	                </div>
				</div>
				<div class="footer-right col-6">
					<div class="copyright_text">
                        <p>LA DOLCE VITA TRADING COMPANY LIMITED</p> 
                        <p>DKKD 0107439368 by KHDT Hanoi dated 19/5/2016</p> 
                        <p>Representative: VU HOANG VU</p> 
                        <p>Location: 224 Thai Ha, Trung Liet, Dong Da, Hanoi</p> 
                        <p>Hotline: 024 7107 9191</p> 
                        <p>Email: Dolcevitacompany9@gmail.com</p>                                                                            
                    </div>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="col-12">
			<div class="row">
				<div id="social">
				<a href="https://fb.com/maisonmikenco" class="icon-social"><img src="http://mikenco.vn/wp-content/uploads/2020/04/facebook_logos_PNG19751.png"></a>
				<a href="https://www.instagram.com/mikenco.official/" class="icon-social"><img src="http://mikenco.vn/wp-content/uploads/2020/04/instagram-logos-png-images-free-download-2.png"></a>
				<a href="https://www.youtube.com/channel/UCqBiGybwHlURMwlVByCMwtQ" class="icon-social"><img src="http://mikenco.vn/wp-content/uploads/2020/04/youtube_PNG18.png"></a>

				<a href="https://vt.tiktok.com/hdCqKN/" class="icon-social"><img src="http://mikenco.vn/wp-content/uploads/2020/04/34509a05557bf30853af477a83b7c7bb-copy.png"></a>
				<a href="https://shopee.vn/mikenco.official" class="icon-social"><img src="http://mikenco.vn/wp-content/uploads/2020/04/shopee-1.png"></a>
				<a href="https://tiki.vn/cua-hang/la-dolce-vita" class="icon-social"><img src="http://mikenco.vn/wp-content/uploads/2020/04/tiki_21.1k.png"></a>
				<a href="https://www.lazada.vn/shop/la-dolce-vita" class="icon-social"><img src="http://mikenco.vn/wp-content/uploads/2020/04/Lazada-App-Icon.png"></a>
				<div class="clearfix"></div>
				</div>
			</div>
		</div>
       <div class="clearfix"></div>
	</footer>
</div><!-- #page -->

    <!-- Facebook Pixel Event Code -->
    <script type='text/javascript'>
        document.addEventListener( 'wpcf7mailsent', function( event ) {
        if( "fb_pxl_code" in event.detail.apiResponse){
          eval(event.detail.apiResponse.fb_pxl_code);
        }
      }, false );
    </script>
    <!-- End Facebook Pixel Event Code -->
    			<!-- Facebook Pixel Code -->
			<noscript>
				<img
					height="1"
					width="1"
					style="display:none"
					alt="fbpx"
					src="https://www.facebook.com/tr?id=1157378277937540&ev=PageView&noscript=1"
				/>
			</noscript>
			<!-- End Facebook Pixel Code -->
			
					<div
						attribution="fbe_woocommerce"
						class="fb-customerchat"
						page_id="159608841112881"
					></div>
					<!-- Facebook JSSDK -->
					<script>
					  window.fbAsyncInit = function() {
					    FB.init({
					      appId            : '',
					      autoLogAppEvents : true,
					      xfbml            : true,
					      version          : 'v4.0'
					    });
					  };

					  (function(d, s, id){
					      var js, fjs = d.getElementsByTagName(s)[0];
					      if (d.getElementById(id)) {return;}
					      js = d.createElement(s); js.id = id;
					      js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
					      fjs.parentNode.insertBefore(js, fjs);
					    }(document, 'script', 'facebook-jssdk'));
					</script>
					<div></div>
						<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<link rel='stylesheet' id='berocket_lmp_style-css'  href='https://mikenco.vn/wp-content/plugins/load-more-products-for-woocommerce/css/load_products.css?ver=1.1.8' media='all' />
<script src='https://mikenco.vn/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70' id='jquery-blockui-js'></script>
<script id='wc-add-to-cart-js-extra'>
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"Xem gi\u1ecf h\u00e0ng","cart_url":"https:\/\/mikenco.vn\/cart\/","is_cart":"","cart_redirect_after_add":"yes"};
</script>
<script src='https://mikenco.vn/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=5.2.2' id='wc-add-to-cart-js'></script>
<script src='https://mikenco.vn/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4' id='js-cookie-js'></script>
<script id='woocommerce-js-extra'>
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
</script>
<script src='https://mikenco.vn/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=5.2.2' id='woocommerce-js'></script>
<script id='wc-cart-fragments-js-extra'>
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_9ae473370c19e321ff00ce34bb868f13","fragment_name":"wc_fragments_9ae473370c19e321ff00ce34bb868f13","request_timeout":"5000"};
</script>
<script src='https://mikenco.vn/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=5.2.2' id='wc-cart-fragments-js'></script>
<script src='https://mikenco.vn/wp-content/themes/mikenco/js/navigation.js?ver=1.0.0' id='mikenco-navigation-js'></script>
<script src='https://mikenco.vn/wp-content/themes/mikenco/js/skip-link-focus-fix.js?ver=1.0.0' id='mikenco-skip-link-focus-fix-js'></script>
<script src='https://mikenco.vn/wp-includes/js/wp-embed.min.js?ver=5.7.1' id='wp-embed-js'></script>
<script id='berocket_lmp_js-js-extra'>
var the_lmp_js_data = {"type":"infinity_scroll","update_url":"","use_mobile":"","mobile_type":"","mobile_width":"","is_AAPF":"","buffer":"50","use_prev_btn":"","load_image":"<div class=\"lmp_products_loading\"><i class=\"fa fa-spinner lmp_rotate\"><\/i><span class=\"\"><\/span><\/div>","load_img_class":".lmp_products_loading","load_more":"<div class=\"lmp_load_more_button br_lmp_button_settings\"><a class=\"lmp_button \" style=\"font-size: 22px;color: #333333;background-color: #ffffff;padding-top:15px;padding-right:25px;padding-bottom:15px;padding-left:25px;margin-top:px;margin-right:px;margin-bottom:px;margin-left:px; border-top: 0px solid #000; border-bottom: 0px solid #000; border-left: 0px solid #000; border-right: 0px solid #000; border-top-left-radius: 0px; border-top-right-radius: 0px; border-bottom-left-radius: 0px; border-bottom-right-radius: 0px;\" href=\"#load_next_page\">Load More<\/a><\/div>","load_prev":"<div class=\"lmp_load_more_button br_lmp_prev_settings\"><a class=\"lmp_button \" style=\"font-size: 22px;color: #333333;background-color: #aaaaff;padding-top:15px;padding-right:25px;padding-bottom:15px;padding-left:25px;margin-top:px;margin-right:px;margin-bottom:px;margin-left:px; border-top: 0px solid #000; border-bottom: 0px solid #000; border-left: 0px solid #000; border-right: 0px solid #000; border-top-left-radius: 0px; border-top-right-radius: 0px; border-bottom-left-radius: 0px; border-bottom-right-radius: 0px;\" href=\"#load_next_page\">Load Previous<\/a><\/div>","lazy_load":"","lazy_load_m":"","LLanimation":"","end_text":"<div class=\"lmp_products_loading\"><span class=\"\"><\/span><\/div>","javascript":{"before_update":"","after_update":""},"products":"ul.products","item":"li.product","pagination":".woocommerce-pagination","next_page":".woocommerce-pagination a.next","prev_page":".woocommerce-pagination a.prev"};
</script>
<script src='https://mikenco.vn/wp-content/plugins/load-more-products-for-woocommerce/js/load_products.js?ver=1.1.8' id='berocket_lmp_js-js'></script>
<script id='jquery-dgwt-wcas-js-extra'>
var dgwt_wcas = {"labels":{"category":"Danh m\u1ee5c","tag":"Tag","brand":"Th\u01b0\u01a1ng hi\u1ec7u","post":"B\u00e0i vi\u1ebft","page":"Page","vendor":"Vendor","product_cat_plu":"Danh m\u1ee5c","product_tag_plu":"Th\u1ebb","product_plu":"S\u1ea3n ph\u1ea9m","brand_plu":"Th\u01b0\u01a1ng hi\u1ec7u","post_plu":"B\u00e0i vi\u1ebft","page_plu":"Trang","vendor_plu":"Vendors","sku_label":"M\u00e3 s\u1ea3n ph\u1ea9m:","sale_badge":"Khuy\u1ebfn m\u1ea1i","vendor_sold_by":"Sold by:","featured_badge":"N\u1ed5i b\u1eadt","in":"trong","read_more":"\u0111\u1ecdc ti\u1ebfp","no_results":"No results","show_more":"See all products...","show_more_details":"See all products...","search_placeholder":"T\u00ecm ki\u1ebfm s\u1ea3n ph\u1ea9m...","submit":"Search"},"ajax_search_endpoint":"\/?wc-ajax=dgwt_wcas_ajax_search","ajax_details_endpoint":"\/?wc-ajax=dgwt_wcas_result_details","ajax_prices_endpoint":"\/?wc-ajax=dgwt_wcas_get_prices","action_search":"dgwt_wcas_ajax_search","action_result_details":"dgwt_wcas_result_details","action_get_prices":"dgwt_wcas_get_prices","min_chars":"3","width":"auto","show_details_box":"","show_images":"1","show_price":"","show_desc":"","show_sale_badge":"","show_featured_badge":"","dynamic_prices":"","is_rtl":"","show_preloader":"1","show_headings":"1","preloader_url":"","taxonomy_brands":"","img_url":"https:\/\/mikenco.vn\/wp-content\/plugins\/ajax-search-for-woocommerce\/assets\/img\/","is_premium":"","mobile_breakpoint":"992","mobile_overlay_wrapper":"body","debounce_wait_ms":"400","send_ga_events":"1","enable_ga_site_search_module":"","magnifier_icon":"\t\t\t\t<svg version=\"1.1\" class=\"\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"\n\t\t\t\t\t xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\"\n\t\t\t\t\t viewBox=\"0 0 51.539 51.361\" enable-background=\"new 0 0 51.539 51.361\" xml:space=\"preserve\">\n\t\t             <path fill=\"#444\" d=\"M51.539,49.356L37.247,35.065c3.273-3.74,5.272-8.623,5.272-13.983c0-11.742-9.518-21.26-21.26-21.26 S0,9.339,0,21.082s9.518,21.26,21.26,21.26c5.361,0,10.244-1.999,13.983-5.272l14.292,14.292L51.539,49.356z M2.835,21.082 c0-10.176,8.249-18.425,18.425-18.425s18.425,8.249,18.425,18.425S31.436,39.507,21.26,39.507S2.835,31.258,2.835,21.082z\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t","close_icon":"\t\t\t\t<svg class=\"\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\">\n\t\t\t\t\t<path fill=\"#ccc\" d=\"M18.3 5.71c-.39-.39-1.02-.39-1.41 0L12 10.59 7.11 5.7c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L10.59 12 5.7 16.89c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0L12 13.41l4.89 4.89c.39.39 1.02.39 1.41 0 .39-.39.39-1.02 0-1.41L13.41 12l4.89-4.89c.38-.38.38-1.02 0-1.4z\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t","back_icon":"\t\t\t\t<svg class=\"\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" viewBox=\"0 0 16 16\">\n\t\t\t\t\t<path fill=\"#fff\" d=\"M14 6.125H3.351l4.891-4.891L7 0 0 7l7 7 1.234-1.234L3.35 7.875H14z\" fill-rule=\"evenodd\" \/>\n\t\t\t\t<\/svg>\n\t\t\t\t","preloader_icon":"\t\t\t\t<svg class=\"dgwt-wcas-loader-circular \"  viewBox=\"25 25 50 50\">\n\t\t\t\t\t<circle class=\"dgwt-wcas-loader-circular-path\" cx=\"50\" cy=\"50\" r=\"20\" fill=\"none\" stroke=\"#ddd\" stroke-miterlimit=\"10\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t","custom_params":{},"convert_html":"1","suggestions_wrapper":"body","show_product_vendor":""};
</script>
<script src='https://mikenco.vn/wp-content/plugins/ajax-search-for-woocommerce/assets/js/search.min.js?ver=1.9.0' id='jquery-dgwt-wcas-js'></script>

</body>
</html>
